import importlib.abc
import importlib.util
import os
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad

class EncryptedModuleLoader(importlib.abc.Loader):
    def __init__(self, path, key, iv):
        self.path = path
        self.key = key
        self.iv = iv

    def create_module(self, spec):
        return None  # Default

    def exec_module(self, module):
        with open(self.path, "rb") as f:
            ciphertext = f.read()
        cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
        decrypted = unpad(cipher.decrypt(ciphertext), AES.block_size)
        exec(decrypted, module.__dict__)

class EncryptedModuleFinder(importlib.abc.MetaPathFinder):
    def __init__(self, key, iv):
        self.key = key
        self.iv = iv
        self.module_map = {
            "ge_validation_execution.ge_validation_execution_encrypted": os.path.join(os.path.dirname(__file__), "ge_validation_execution_encrypted.enc"),
        }

    def find_spec(self, fullname, path, target=None):
        if fullname in self.module_map:
            enc_path = self.module_map[fullname]
            loader = EncryptedModuleLoader(enc_path, self.key, self.iv)
            return importlib.util.spec_from_loader(fullname, loader)
        return None
